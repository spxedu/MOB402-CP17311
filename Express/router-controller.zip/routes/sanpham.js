var express = require('express');
var router = express.Router();
var spController = require('../controllers/sanpham.controller')

// hiển thị danh sách
router.get('/', spController.getList );

// hiện form add:
router.get('/add', spController.addProduct);


// phải export router
module.exports = router;