var express = require('express');
var router = express.Router();
var spController = require('../controllers/sanpham.controller')

// hiển thị danh sách
router.get('/', spController.getList );

// hiện form add:
router.get('/add', spController.addProduct);
router.post('/add', spController.addProduct); 

router.get('/edit/:id', (req,res,next)=>{
        console.log("Truyền tham số bằng params: ");
        console.log(req.params);

        console.log("Truyền tham số theo query: ");
        console.log(req.query);
        res.send( req.params );
})
// phải export router
module.exports = router;