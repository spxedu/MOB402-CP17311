exports.getList = (req,res, next)=>{
    let bien = "Nguyen Van A";

    let objSP = { id: 1, name: 'Điện thoại', price: 40000}

    res.render('sanpham/list', { user: bien, sp: objSP }   );
}

exports.addProduct = (req,res, next)=>{

    console.log(req.url);
    console.log(req.body); // dữ liệu POST 
    let ten_sp ='';
    if( typeof(req.body.tensp) != 'undefined' ) 
        ten_sp  = req.body.tensp;

    res.render('sanpham/add',{ msg: "Dữ liệu: " + ten_sp } );
}

